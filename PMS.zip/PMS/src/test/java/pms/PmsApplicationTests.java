package pms;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
