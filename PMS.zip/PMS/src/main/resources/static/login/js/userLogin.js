$("#verifyImg").click(function() {
    this.src = "/user/code?" + new Date().getTime()
})


$(".layui-canvs").jParticle({
    background: "#141414",
    color: "#E6E6E6"
});


//验证验证码
function valid(code) {
    var flag;
    $.ajax({
        url: "/sys/code",
        data: { "code": code },
        type: "POST",
        dataType: "json",
        async: false,
        success: function(data) {
            if (data == true)
                flag = true
            else
                flag = false
        }
    })
    return flag;
}

$(".submit_btn").click(function() {
    $("#data").css("display", 'none')
    var username = $("#username").val()
    var password = $("#password").val();
    var code = $("#code").val();
    if (username == null || username == "") {
        layer.tips("用户名不能为空", "#username")
        return;
    }
    if (password == null || password == "") {
        layer.tips("密码不能为空", "#password")
        return;
    }
    if (code == null || code == "") {
        layer.tips("验证码不能为空", "#code")
        return;
    }
    if (!valid(code)) {
        layer.tips("验证码不对哦", "#CODE")
        $("#code").val("");
        $("#verifyImg").attr("src", "/user/code?" + new Date().getTime());
        return;
    }
    $.ajax({
        url: "/sys/login",
        data: {
            "username": username,
            "password": password
        },
        type: "POST",
        success: function(data) {
            if (data == "user") {
                layer.msg("登录成功，正在为您跳转", {
                    time: 2000,
                    end: function() {
                        location.href = "/start/user.html"
                    }
                });
            } else if (data == "admin") {
                layer.msg("登录成功，正在为您跳转", {
                    time: 2000,
                    end: function() {
                        location.href = "/start/admin.html"
                    }
                });
            } else {
                $("#data").css("display", '')
                $("#data").html("用户名或者密码错误")
                $("#verifyImg").attr("src", "/user/code?" + new Date().getTime());
            }
        }
    })

});