$("#verifyImg").click(function() {
    this.src = "/user/code?" + new Date().getTime()
})


$(".layui-canvs").jParticle({
    background: "#141414",
    color: "#E6E6E6"
});


//验证验证码
function valid(code) {
    var flag;
    $.ajax({
        url: "/sys/code",
        data: { "code": code },
        type: "POST",
        dataType: "json",
        async: false,
        success: function(data) {
            if (data == true)
                flag = true
            else
                flag = false
        }
    })
    return flag;
}

$(".submit_btn").click(function() {
    var username = $("#username").val()
    var password = $("#password").val();
    var code = $("#code").val();
    var email = $("#email").val();
    if (username == null || username == "") {
        layer.tips("用户名不能为空", "#username")
        return;
    }
    if (password == null || password == "") {
        layer.tips("密码不能为空", "#password")
        return;
    }
    if (code == null || code == "") {
        layer.tips("验证码不能为空", "#code")
        return;
    }
    if (email == null || email == "") {
        layer.tips("邮箱不能为空", "#email")
        return;
    }
    var reg = new RegExp("^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$");
    if (!reg.test(email)) {
        layer.tips("邮箱格式不正确", "#email")
        return;
    }
    if (!valid(code)) {
        layer.tips("验证码不对哦", "#CODE")
        $("#code").val("");
        $("#verifyImg").attr("src", "/user/code?" + new Date().getTime());
        return;
    }
    $.ajax({
        url: "/sys/register",
        data: {
            "username": username,
            "password": password,
            "email": email
        },
        type: "POST",
        success: function(data) {
            if (data.code == 0) {
                layer.msg(data.msg, {
                    time: 2000,
                    end: function() {
                        location.href = "/sys/login"
                    }
                });
            } else {
                $("#data").css("display", '')
                $("#data").html(data.msg)
                $("#verifyImg").attr("src", "/user/code?" + new Date().getTime());
            }
        }
    })

});