$("#verifyImg").click(function() {
    this.src = "/user/code?" + new Date().getTime()
})


$(".layui-canvs").jParticle({
    background: "#141414",
    color: "#E6E6E6"
});


//验证验证码
function valid(code) {
    var flag;
    $.ajax({
        url: "/sys/code",
        data: { "code": code },
        type: "POST",
        dataType: "json",
        async: false,
        success: function(data) {
            if (data == true)
                flag = true
            else
                flag = false
        }
    })
    return flag;
}

$(".submit_btn").click(function() {
    $("#data").css("display", 'none')
    var email = $("#email").val()
    var code = $("#code").val();

    if (email == null || email == "") {
        layer.tips("邮箱不能为空", "#email")
        return;
    }
    if (code == null || code == "") {
        layer.tips("验证码不能为空", "#code")
        return;
    }
    if (!valid(code)) {
        layer.tips("验证码不对哦", "#CODE")
        $("#code").val("");
        $("#verifyImg").attr("src", "/user/code?" + new Date().getTime());
        return;
    }
    $.ajax({
        url: "/email",
        data: {
            "email": email
        },
        dataType: "json",
        type: "POST",
        success: function(data) {
            if (data.code == 0) {
                layer.msg(data.msg, {
                    time: 2000,
                    end: function() {
                        location.href = "/sys/login"
                    }
                });
            } else {
                $("#data").css("display", '')
                $("#data").html(data.msg)
                $("#verifyImg").attr("src", "/user/code?" + new Date().getTime());
            }
        }
    })

});