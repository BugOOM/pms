package pms.service;

import pms.entity.Model;
import pms.entity.Pay;

public interface PayService {
	Model insertPay(Pay pay);
}
