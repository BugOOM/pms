package pms.service;

public interface HouseService {
	void updateHouse(Integer houseId, Integer ownerId);
}
